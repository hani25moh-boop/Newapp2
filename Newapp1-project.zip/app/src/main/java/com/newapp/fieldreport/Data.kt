package com.newapp.fieldreport

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activities")
data class ActivityItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val unit: String
)

@Entity(tableName = "reports")
data class Report(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val activityName: String,
    val unit: String,
    val quantity: Double,
    val notes: String,
    val createdAt: Long
)

@Dao
interface AppDao {
    @Query("SELECT * FROM activities ORDER BY name")
    fun activities(): Flow<List<ActivityItem>>

    @Query("SELECT COUNT(*) FROM activities")
    suspend fun activityCount(): Int

    @Insert
    suspend fun insertActivity(item: ActivityItem): Long

    @Insert
    suspend fun insertActivities(items: List<ActivityItem>)

    @Delete
    suspend fun deleteActivity(item: ActivityItem)

    @Query("SELECT * FROM reports WHERE date = :date ORDER BY createdAt DESC")
    fun reportsByDate(date: String): Flow<List<Report>>

    @Query("SELECT * FROM reports WHERE date = :date ORDER BY createdAt ASC")
    suspend fun reportsForExport(date: String): List<Report>

    @Insert
    suspend fun insertReport(report: Report): Long

    @Delete
    suspend fun deleteReport(report: Report)
}

@Database(entities = [ActivityItem::class, Report::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "fieldreport.db"
                ).build().also { instance = it }
            }
    }
}

val DEFAULT_ACTIVITIES = listOf(
    ActivityItem(name = "حفر", unit = "م³"),
    ActivityItem(name = "صب خرسانة عادية", unit = "م³"),
    ActivityItem(name = "صب خرسانة مسلحة", unit = "م³"),
    ActivityItem(name = "حديد تسليح", unit = "طن"),
    ActivityItem(name = "بناء بلوك", unit = "م²"),
    ActivityItem(name = "لياسة", unit = "م²"),
    ActivityItem(name = "بلاط / سيراميك", unit = "م²"),
    ActivityItem(name = "دهانات", unit = "م²"),
    ActivityItem(name = "أعمال سباكة", unit = "م.ط"),
    ActivityItem(name = "أعمال كهرباء", unit = "م.ط")
)
