@file:OptIn(ExperimentalMaterial3Api::class)

package com.newapp.fieldreport

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("تقرير الموقع اليومي") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("📝") },
                    label = { Text("التقرير") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("🏗") },
                    label = { Text("الأنشطة") }
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (tab == 0) EntryScreen(vm) else ActivitiesScreen(vm)
        }
    }
}

@Composable
fun EntryScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val activities by vm.activities.collectAsState()
    val reports by vm.reports.collectAsState()
    val date by vm.date.collectAsState()

    var selected by remember { mutableStateOf<ActivityItem?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var quantity by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<Report?>(null) }

    toDelete?.let { r ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف السجل") },
            text = { Text("هل تريد حذف سجل ${r.activityName}؟") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteReport(r)
                    toDelete = null
                }) { Text("حذف") }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("إلغاء") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { vm.shiftDate(-1) }) { Text("اليوم السابق") }
                Text(
                    text = date.toString(),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = { vm.shiftDate(1) }) { Text("اليوم التالي") }
            }
        }
        item {
            Box(Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { menuOpen = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(selected?.let { "${it.name} (${it.unit})" } ?: "اختر النشاط")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    activities.forEach { a ->
                        DropdownMenuItem(
                            text = { Text("${a.name} (${a.unit})") },
                            onClick = {
                                selected = a
                                menuOpen = false
                            }
                        )
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = quantity,
                onValueChange = { quantity = it },
                label = { Text("الكمية المنفذة") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("ملاحظات") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Button(
                onClick = {
                    val activity = selected
                    val qty = parseNumber(quantity)
                    when {
                        activity == null -> toast(context, "اختر النشاط أولاً")
                        qty == null || qty <= 0.0 -> toast(context, "أدخل كمية صحيحة")
                        else -> {
                            vm.saveReport(activity, qty, notes.trim())
                            quantity = ""
                            notes = ""
                            toast(context, "تم الحفظ")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("حفظ") }
        }
        item { HorizontalDivider() }
        item {
            Text(
                text = "سجلات اليوم (${reports.size})",
                style = MaterialTheme.typography.titleMedium
            )
        }
        items(reports, key = { it.id }) { r ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(r.activityName, fontWeight = FontWeight.Bold)
                        Text("${formatQty(r.quantity)} ${r.unit}")
                        if (r.notes.isNotBlank()) {
                            Text(r.notes, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    TextButton(onClick = { toDelete = r }) { Text("حذف") }
                }
            }
        }
        item {
            Button(
                onClick = {
                    scope.launch {
                        val file = vm.buildExport()
                        if (file == null) {
                            toast(context, "لا توجد سجلات لهذا اليوم")
                        } else {
                            shareFile(context, file)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("تصدير Excel ومشاركته") }
        }
    }
}

@Composable
fun ActivitiesScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val activities by vm.activities.collectAsState()
    var name by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<ActivityItem?>(null) }

    toDelete?.let { a ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف النشاط") },
            text = { Text("هل تريد حذف ${a.name} من القائمة؟ السجلات السابقة لن تتأثر.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteActivity(a)
                    toDelete = null
                }) { Text("حذف") }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("إلغاء") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("إضافة نشاط جديد", style = MaterialTheme.typography.titleMedium) }
        item {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("اسم النشاط") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = unit,
                onValueChange = { unit = it },
                label = { Text("الوحدة (م³ ، م² ، طن ...)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Button(
                onClick = {
                    if (name.isBlank() || unit.isBlank()) {
                        toast(context, "أدخل الاسم والوحدة")
                    } else {
                        vm.addActivity(name.trim(), unit.trim())
                        name = ""
                        unit = ""
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("إضافة") }
        }
        item { HorizontalDivider() }
        items(activities, key = { it.id }) { a ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${a.name} (${a.unit})", Modifier.weight(1f))
                    TextButton(onClick = { toDelete = a }) { Text("حذف") }
                }
            }
        }
    }
}

private fun toast(context: Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}

private fun formatQty(q: Double): String =
    if (q % 1.0 == 0.0) q.toLong().toString() else q.toString()

/** Parses numbers typed with Western or Arabic-Indic digits; accepts . , and Arabic decimal/comma as separators. */
private fun parseNumber(text: String): Double? {
    val sb = StringBuilder()
    for (c in text.trim()) {
        when (c) {
            in '\u0660'..'\u0669' -> sb.append('0' + (c - '\u0660'))
            '\u066B', ',', '\u060C' -> sb.append('.')
            else -> sb.append(c)
        }
    }
    return sb.toString().toDoubleOrNull()
}

private fun shareFile(context: Context, file: File) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "مشاركة ملف Excel"))
}
