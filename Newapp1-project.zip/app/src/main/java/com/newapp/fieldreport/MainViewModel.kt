package com.newapp.fieldreport

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.get(app).dao()

    val activities: StateFlow<List<ActivityItem>> =
        dao.activities().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _date = MutableStateFlow(LocalDate.now())
    val date: StateFlow<LocalDate> = _date

    @OptIn(ExperimentalCoroutinesApi::class)
    val reports: StateFlow<List<Report>> = _date
        .flatMapLatest { dao.reportsByDate(it.toString()) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            if (dao.activityCount() == 0) {
                dao.insertActivities(DEFAULT_ACTIVITIES)
            }
        }
    }

    fun shiftDate(days: Long) {
        _date.value = _date.value.plusDays(days)
    }

    fun saveReport(activity: ActivityItem, quantity: Double, notes: String) {
        viewModelScope.launch {
            dao.insertReport(
                Report(
                    date = _date.value.toString(),
                    activityName = activity.name,
                    unit = activity.unit,
                    quantity = quantity,
                    notes = notes,
                    createdAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun deleteReport(report: Report) {
        viewModelScope.launch { dao.deleteReport(report) }
    }

    fun addActivity(name: String, unit: String) {
        viewModelScope.launch { dao.insertActivity(ActivityItem(name = name, unit = unit)) }
    }

    fun deleteActivity(item: ActivityItem) {
        viewModelScope.launch { dao.deleteActivity(item) }
    }

    /** Builds the Excel file for the currently selected day. Returns null if there are no records. */
    suspend fun buildExport(): File? = withContext(Dispatchers.IO) {
        val day = _date.value.toString()
        val list = dao.reportsForExport(day)
        if (list.isEmpty()) {
            null
        } else {
            val dir = File(getApplication<Application>().cacheDir, "exports")
            dir.mkdirs()
            dir.listFiles()?.forEach { it.delete() }
            val file = File(dir, "FieldReport_$day.xlsx")
            XlsxWriter.write(
                file,
                listOf("التاريخ", "النشاط", "الوحدة", "الكمية", "الملاحظات"),
                list.map { listOf<Any>(it.date, it.activityName, it.unit, it.quantity, it.notes) }
            )
            file
        }
    }
}
